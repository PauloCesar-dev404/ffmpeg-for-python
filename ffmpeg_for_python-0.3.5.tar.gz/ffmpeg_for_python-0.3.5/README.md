
<div align="center">
    <img src="assets/ffmpeg-for-python-logo.png" alt="ffmpeg-for-python-logo" width="200"/>



![Versão](https://img.shields.io/badge/version-0.3.5-orange)
![Licença](https://img.shields.io/badge/license-MIT-orange)
[![Sponsor](https://img.shields.io/badge/💲Donate-yellow)](https://apoia.se/paulocesar-dev404)

</div>

Wrapper para o binário FFmpeg, permitindo o uso de comandos FFmpeg via Python. Para saber como usar FFmpeg, consulte [a documentação no site oficial](https://ffmpeg.org/ffmpeg.html).

---
